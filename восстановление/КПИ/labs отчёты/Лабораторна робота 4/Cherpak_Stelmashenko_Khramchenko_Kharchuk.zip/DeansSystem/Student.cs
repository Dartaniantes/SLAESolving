using System;

namespace DeansSystem
{
    public class Student : User
    {
        private string login;
        private FileOperations _fo;
        private Output _output;

        public Student(string login, string path, string fileName) : base(login, path, fileName)
        {
            this.login = login;
            _fo = new FileOperations(path, fileName);
            _output = new Output();
        }
        public void CheckYourMarks()
        {
            FileOperations fops = new FileOperations(_output.path, _output.marksFile);
            string[] marks = fops.GetLine(login).Split(",", StringSplitOptions.RemoveEmptyEntries);
            string line = "Your marks: ";
            if (marks.Length == 1)
            {
                Console.Clear();
                line = "You have no marks!";
            }
            else for (int i = 1; i < marks.Length; i++)
            {
                line += marks[i];
                if (i + 1 < marks.Length) line += ", ";
            }
            _output.LineOutput(line);
        }
        public void CheckGroup()
        {
            _fo = new FileOperations(_output.path, _output.studentsFile);
            string[] splited = _fo.GetLine(login).Split(",", StringSplitOptions.RemoveEmptyEntries);
            _output.LineOutput("Your group: "+splited[1]);
        }
        public void CheckCourse()
        {
            _fo = new FileOperations(_output.path, _output.studentsFile);
            string[] splited = _fo.GetLine(login).Split(",", StringSplitOptions.RemoveEmptyEntries);
            _output.LineOutput("Your course: "+splited[2]);
        }
    }
}
