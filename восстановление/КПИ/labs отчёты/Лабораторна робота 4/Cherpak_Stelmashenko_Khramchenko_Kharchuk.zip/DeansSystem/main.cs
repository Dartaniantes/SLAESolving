﻿using System;

namespace DeansSystem
{
    public class Program
    {
        static void Main(string[] args)
        {
            Output o = new Output();
            o.StartWork();
        }
    }
}